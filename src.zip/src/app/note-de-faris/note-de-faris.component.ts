import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-note-de-faris',
  templateUrl: './note-de-faris.component.html',
  styleUrls: ['./note-de-faris.component.scss']
})
export class NoteDeFarisComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
