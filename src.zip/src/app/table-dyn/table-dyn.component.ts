import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-table-dyn',
  templateUrl: './table-dyn.component.html',
  styleUrls: ['./table-dyn.component.scss']
})
export class TableDynComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
