import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partie-proj',
  templateUrl: './partie-proj.component.html',
  styleUrls: ['./partie-proj.component.scss']
})
export class PartieProjComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
