import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dial-edit-brand',
  templateUrl: './dial-edit-brand.component.html',
  styleUrls: ['./dial-edit-brand.component.scss']
})
export class DialEditBrandComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
