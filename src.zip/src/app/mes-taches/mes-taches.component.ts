import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mes-taches',
  templateUrl: './mes-taches.component.html',
  styleUrls: ['./mes-taches.component.scss']
})
export class MesTachesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
