import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dash-cons',
  templateUrl: './dash-cons.component.html',
  styleUrls: ['./dash-cons.component.scss']
})
export class DashConsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
