import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maladie',
  templateUrl: './maladie.component.html',
  styleUrls: ['./maladie.component.scss']
})
export class MaladieComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
