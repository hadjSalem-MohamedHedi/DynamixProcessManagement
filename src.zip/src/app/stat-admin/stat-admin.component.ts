import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stat-admin',
  templateUrl: './stat-admin.component.html',
  styleUrls: ['./stat-admin.component.scss']
})
export class StatAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
