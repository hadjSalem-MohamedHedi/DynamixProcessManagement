export interface Consultant {
  id: string;
  nom: string;
  prenom: string;
  cin: string;
}
