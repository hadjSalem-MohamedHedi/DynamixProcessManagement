export interface Customer {
  cin: string;
  name: 'ok';
}
