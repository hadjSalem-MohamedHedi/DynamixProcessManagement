import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-cons',
  templateUrl: './home-cons.component.html',
  styleUrls: ['./home-cons.component.scss']
})
export class HomeConsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
