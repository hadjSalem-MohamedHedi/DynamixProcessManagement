import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-custo',
  templateUrl: './project-custo.component.html',
  styleUrls: ['./project-custo.component.scss']
})
export class ProjectCustoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
