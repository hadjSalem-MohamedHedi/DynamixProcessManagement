import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-autorisation',
  templateUrl: './autorisation.component.html',
  styleUrls: ['./autorisation.component.scss']
})
export class AutorisationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
