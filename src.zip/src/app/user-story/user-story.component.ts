import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-story',
  templateUrl: './user-story.component.html',
  styleUrls: ['./user-story.component.scss']
})
export class UserStoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
