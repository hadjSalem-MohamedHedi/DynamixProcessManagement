import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-custo',
  templateUrl: './home-custo.component.html',
  styleUrls: ['./home-custo.component.scss']
})
export class HomeCustoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
