import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar-right',
  templateUrl: './navbar-right.component.html',
  styleUrls: ['./navbar-right.component.scss']
})
export class NavbarRightComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
