import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conges',
  templateUrl: './conges.component.html',
  styleUrls: ['./conges.component.scss']
})
export class CongesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
