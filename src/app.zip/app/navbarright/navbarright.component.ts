import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbarright',
  templateUrl: './navbarright.component.html',
  styleUrls: ['./navbarright.component.scss']
})
export class NavbarrightComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
