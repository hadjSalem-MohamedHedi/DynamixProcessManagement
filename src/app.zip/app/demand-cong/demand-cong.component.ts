import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demand-cong',
  templateUrl: './demand-cong.component.html',
  styleUrls: ['./demand-cong.component.scss']
})
export class DemandCongComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
