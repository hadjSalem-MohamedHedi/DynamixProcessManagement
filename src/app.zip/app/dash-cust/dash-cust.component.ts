import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dash-cust',
  templateUrl: './dash-cust.component.html',
  styleUrls: ['./dash-cust.component.scss']
})
export class DashCustComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
