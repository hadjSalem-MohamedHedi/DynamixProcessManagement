import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demand-auto',
  templateUrl: './demand-auto.component.html',
  styleUrls: ['./demand-auto.component.scss']
})
export class DemandAutoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
